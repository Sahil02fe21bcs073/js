function validateAndSubmit(event) {
    event.preventDefault();

    const firstName = document.getElementById('first-name').value;
    const lastName = document.getElementById('last-name').value;
    const mobileNo = document.getElementById('mobile-no').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!isValidName(firstName) || !isValidName(lastName)) {
        alert('Please enter valid first and last names.');
        return;
    }

    if (!isValidPhone(mobileNo)) {
        alert('Please enter a valid mobile number.');
        return;
    }

    if (!isValidEmail(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    if (!isValidPassword(password)) {
        alert('Please enter a password with at least 8 characters.');
        return;
    }

    // Redirect to index.html after successful validation
    window.location.href = 'index.html';
}

function isValidName(name) {
    return /^[a-zA-Z]+$/.test(name.trim());
}

function isValidPhone(phone) {
    return /^\d{10}$/.test(phone.trim());
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function isValidPassword(password) {
    return password.length >= 8;
}
